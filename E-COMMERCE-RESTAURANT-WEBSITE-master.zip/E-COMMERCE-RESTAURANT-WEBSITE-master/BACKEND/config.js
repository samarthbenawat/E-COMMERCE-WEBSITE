const mongodb=require('mongodb')
const DB_NAME="ECOMMERCE"
const PORT=4444
const DB_URL="mongodb://localhost:27017"+DB_NAME
module.exports={DB_NAME,DB_URL,PORT}
