# E-COMMERCE-RESTAURANT-WEBSITE
### This project contains both backend and frontend of restaurant e-commerce website.
## ABOUT
### 1.It contains login ,regsiter and home page of e-commerce website.
### 2.Implemented user authentication .
## TOOLS AND LIBRARIES USED
### 1.Bootstrap frame-work for frontend.
### 2.J-Query library for writing javascript for frontend.
### 3.Passport library for user authentication in backend.
### 4.Express library for creating the server.
### 5.Mongodb database for storing database of users.
### 6.Mongoose library for creating models.

